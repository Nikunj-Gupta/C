#include<stdio.h>
#include<stdlib.h>
#include<math.h>

float compute(float a, float b, float c, float *real1, float *imag1, float *real2)
    {
    float deltasq;
    float imag2;
    deltasq = (b*b) - (4*a*c);
    if(deltasq < 0)
        {
        *imag1 =  pow(-1*deltasq,0.5)/(2*a);
        imag2 = -1*(*imag1);
        *real1 = (-1*b)/(2*a);
        *real2 = (-1*b)/(2*a);
        }
    else
        {
        *real1 = ((-1*b)+pow(deltasq,0.5))/(2*a);
        *real2 = ((-1*b)-pow(deltasq,0.5))/(2*a);
        *imag1 = 0;
        imag2 = 0;
        }
    return imag2;
    }
