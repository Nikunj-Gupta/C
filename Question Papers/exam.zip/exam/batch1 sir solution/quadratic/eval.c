//Took 15 minutes to program

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

float compute(float a, float b, float c, float *real1, float *imag1, float *real2);

int main(int argc, char *argv[])
    {
    float a,b,c,real1, real2, imag1,imag2;
    a = atof(argv[1]);
    b = atof(argv[2]);
    c = atof(argv[3]);

    imag2 = compute(a,b,c,&real1,&imag1,&real2);

    if(imag1!=0)
        {
        printf("root1: %3.2f+%3.2fi\n",real1,imag1);
        printf("root2: %3.2f%3.2fi\n",real2,imag2);
        }
    else
        {
        printf("root1: %3.2f\n",real1);
        printf("root2: %3.2f\n",real2);
        }
    return 1;
    }
