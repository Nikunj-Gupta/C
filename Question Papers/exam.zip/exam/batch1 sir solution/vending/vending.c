//Took 28 minutes to program

#include<stdio.h>

int main(int argc, char *argv[])
    {
    unsigned char items, water, cdrinks, cookies, chocolates;
    int price=0, amount=0;
    scanf("%d",(int*)&items);
    water = (items & 0b10000000) >> 7;
    cdrinks = (items & 0b01100000) >> 5 ;
    cookies = (items & 0b00011000) >> 3 ;
    chocolates = (items & 0b00000111) ;
    price = atoi(argv[1]);
    printf("Items selected:\n");
    amount += (price & 0b1111000000000000000000000)>>21;
    if(water)
        printf("Bisleri\n");
    else
        printf("Kinley\n");
        
    switch (cdrinks)
        {
        case 0:
            printf("Coke\n");
            amount += (price &0b0000111111000000000000000)>>15;
            break;
        case 1:
            printf("Sprite\n");
            amount += (price &0b0000111111000000000000000)>>15;
            break;
        case 2:
            printf("Pepsi\n");
            amount += (price &0b0000111111000000000000000)>>15;
            break;
        default:
            break;
        }
    amount += (price &0b0000000000111111000000000)>>9;
    switch (cookies)
        {
        case 0:
            printf("Bourbon\n");
            break;
        case 1:
            printf("Oreo\n");
            break;
        case 2:
            printf("GoodDay\n");
            break;
        case 3:
            printf("ParleG\n");
            break;
        }

    switch (chocolates)
        {
        case 0:
            printf("Nestle\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 1:
            printf("Fivestar\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 2:
            printf("DairyMilk\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 3:
            printf("Eclairs\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 4:
            printf("Snickers\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 5:
            printf("Hershleys\n");
            amount += (price &0b0000000000000000111111111);
            break;
        case 6:
            printf("BarOne\n");
            amount += (price &0b0000000000000000111111111);
            break;
        default:
            break;
        }
    printf("\nTotal price:\n");
    printf("%d\n",amount);
    return 1;
    }
