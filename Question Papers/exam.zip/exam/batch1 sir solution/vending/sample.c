#include<stdio.h>

int main(int argc, char *argv[])
    {
 //   int x = atoi(argv[1]);
    int y = 0b111110;
    int z = 0b111110;
  //  printf("%d\n",x>>21);
    printf("Total price:%d\n",0b1110 + 0b111110 + 0b111110 + 0b111111110);
    return 1;
    }
