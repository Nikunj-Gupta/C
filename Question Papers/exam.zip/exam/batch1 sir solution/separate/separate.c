//Took 15 minutes to program

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int isPrime(int);

int isPrime(int n)
    {
    int i;
    for (i=2;i<=(int)pow(n,0.5);i++)
        if (n % i == 0)
            return 0;
    return 1;
    }

int main(int argc, char * argv[])
    {
    FILE *even, *odd, *prime;
    int i;
    even = fopen("even.dat","w");
    odd = fopen("odd.dat","w");
    prime = fopen("prime.dat","w");

    for(i=1;i<argc;i++)
        {
        if(isPrime(atoi(argv[i])))
            fprintf(prime,"%d ",atoi(argv[i]));
        else if (atoi(argv[i]) % 2)
            fprintf(odd,"%d ",atoi(argv[i]));
        else
            fprintf(even,"%d ",atoi(argv[i]));
        }
    fclose(even);
    fclose(odd);
    fclose(prime);
    }
