//Took 5 minutes to program

#include<stdio.h>

int main(int argc, char* argv[])
    {
    FILE *in;
    int mpg, miles, num;
    char ttype[200]="";
    float gallons;

    in = fopen(argv[1],"r");
    while(!feof(in))
        {
        fscanf(in,"%s",ttype);
        if(feof(in)) break;
        fscanf(in,"%d",&mpg);
        fscanf(in,"%d",&miles);
        fscanf(in,"%d",&num);
        gallons = gallons + (float)miles/(mpg*num);
        }
    fclose(in);
    printf("%3.2f\n",gallons);
    return 1;
    }
