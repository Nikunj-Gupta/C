//Took 20 minutes to program

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
    {
    FILE *in;

    char str[20]="";
    int samples,i=0, val, count=0, thresholdValue;
    thresholdValue = atoi(argv[1]);
    in = fopen(argv[2],"r");
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    fscanf(in,"%d",&samples);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    while(i<samples)
        {
        fscanf(in,"%d",&val);
        i++;
        if(abs(val) <= thresholdValue) count++;
        }
    fclose(in);
    i = 0;

    in = fopen(argv[2],"r");
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%d",&samples);
    printf("%d\n",count);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    while(i<samples)
        {
        fscanf(in,"%d",&val);
        i++;
        if(abs(val) <= thresholdValue) printf("%d\n",val); 
        }
    fclose(in);

    }
