#include<stdio.h>
#include<string.h>
int main(int agrc,char* agrc[])
	{
	FILE *fin;
	char str[1000] = "",freq_word[1000] = "";
	fin = fopen(argv[1],"r");
	while(!feof.fin())
		{
		
