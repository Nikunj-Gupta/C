#include<stdio.h>
#include<string.h>
#include<math.h>
int main(int argc, char *argv[])
    {
    FILE *in;
    char str[20]="";
    int samples,i=0,count=0,j=0,k=1,value=0,total_count=0,cou=0;
	char val[10]="";
    in = fopen(argv[1],"r");
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
	fscanf(in,"%s",str);
	fscanf(in,"%s",str);
    fscanf(in,"%d",&samples);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
	int pos[samples];
    while(i<samples)
        {
        fscanf(in,"%s",val);
        if(strcmp(val,"!partition")==0)
			{
			pos[j] = i+cou+1;			
			j++;
			i--;
			cou++;
			}
		i++;
		}
	fclose(in);
	in = fopen(argv[1],"r");
	int pos_size = j+1;
	int sam[pos_size];
	for(i=0;i<j;i++)
		{
		for(k=0;k<pos[i]-1;k++)
			{
			count++;
			}
		sam[i] = count;
		total_count += count;
		count = 0;	
		} 
	sam[i] = (samples - total_count);
	fclose(in);
	in = fopen(argv[1],"r");
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s ",str);
	fscanf(in,"%s",str);
	printf("%s\n",str);
	fscanf(in,"%s",str);
	printf("%s ",str);
    fscanf(in,"%d",&samples);
    printf("%d\n",sam[0]);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
	j = 0;
	while(j<sam[0])
		{
		fscanf(in,"%d",&value);
		printf("%d\n",value);
		j++;
		}
	j = 0;
	fclose(in);
	in = fopen(argv[1],"r");
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s ",str);
	fscanf(in,"%s",str);
	printf("%s\n",str);
	fscanf(in,"%s",str);
	printf("%s ",str);
    fscanf(in,"%d",&samples);
    printf("%d\n",sam[1]);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
	while(j<sam[0])
		{
		fscanf(in,"%d",&value);
		j++;
		}
	fscanf(in,"%s",str);
	j = 0;
	while(j<sam[1])
		{
		fscanf(in,"%d",&value);
		printf("%d\n",value);
		j++;
		}
	}
	

