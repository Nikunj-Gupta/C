#include<stdio.h>
#include<stdlib.h>
float head(float arr[])
	{
	return arr[0];
	}

float* tail(float arr[])
	{
	return &arr[1];
	}
char** tail1(char* arr[])
	{
	return &arr[1];
	}

float max(float array[],int n)
	{
	if(n==0)
		return head(array);
	else if(head(array) > max(tail(array),n-1))
		{
		return head(array);
		}
	else
		{
		max(tail(array),n-1);
		}
	} 
  
float* arr(float array[],char* argv[],int n)
	{
	if(n==0)
		return array;
	else
		{
		array[n] = atof(argv[0]);
		arr(array,tail1(argv),n-1);
		}	
	}
	
int main(int argc, char* argv[])
	{
	int n = argc,i=0;
	float highest = 0,*array;
	array = (float*)malloc(sizeof(float)*n);
	array = arr(array,argv,n);
	highest = max(array,n);
	printf("highest:%0.2f\n",highest);
	}
