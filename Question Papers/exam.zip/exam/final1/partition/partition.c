#include<stdio.h>
#include<stdlib.h>
int main(int argv, char *argc[])
    {
    int number1, number2;
    int arr[argv];
    int array[100];
    int i;
    int threshold_val=atoi(argc[1]);
    int amp_factor=atoi(argc[2]);
    char details1[25],details2[25],details3[25],details4[25],details5[25],details6[25],details7[25];
    FILE *input;
    input=fopen(argc[1],"r");//opening file in read mode
    fscanf(input,"%s %s %s %s %d %s %s %s",details1,details2,details3,details4,&number1,details5,details6,details7);	
    for(i=2;i<argv;i++)
	{
	FILE *inp;
	inp = fopen(argc[i],"w");
        fprintf(inp,"%s\n",details1);
        fprintf(inp,"%s %s\n",details2, details3);
        fprintf(inp,"%s %d\n",details4, number1);
        fprintf(inp,"%s %s\n",details5, details6);
        fprintf(inp,"%s\n",details7);
	fclose(inp);	
	}
	while(!feof(input))//reads data from the file till end-of-file is not reached
        {
        fscanf(input,"%d %d",&number1,&number2);
	FILE *inp;
	inp = fopen(argc[number1+1],"a");
	arr[number1+1]+=1;
	fprintf(inp,"%d\n",number2);
	fclose(inp);
	}
	for(i=2;i<argv;i++)
		printf("%d\n", arr[i]);
	for(i=2;i<argv;i++)
	{
	FILE *inp;
	inp = fopen(argc[i],"rw");
	fscanf(inp,"%s %s %s %s %d %s %s %s",details1,details2,details3,details4,&number1,details5,details6,details7);
	while(!feof(inp))
		{
		fscanf(inp, "%d", &number1);
		for(i=0;i<100;i++)
			array[i] = number1;
		}
		fprintf(inp,"%s\n",details1);
		fprintf(inp,"%s %s\n",details2, details3);
		fprintf(inp,"%s %d\n",details4, arr[i]);
		fprintf(inp,"%s %s\n",details5, details6);
		fprintf(inp,"%s\n",details7);
		for(i=0;i<100;i++)
			fprintf(inp,"%d\n",array[i]);
	fclose(inp);	
	}	
	fclose(input);//closing file
	return 1;
    }
