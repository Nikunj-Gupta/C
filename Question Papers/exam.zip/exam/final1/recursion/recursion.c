#include<stdio.h>
#include<stdlib.h>
int memory(double **array, int i, int n, int m)
	{
	if (i==n)
		return 0;
	else	
	{
		array[i] = (double*) malloc(sizeof(double)*m);
		memory(array, i+1, n, m);
	}
	}

int print(double **array, int count1, int count2, int n, int m, int total)
	{
	if(total==n*m)
		return 1;
	else
		{	
		printf("%0.2f ", array[count1][count2]);
		if(count2 == m-1)
		{
			printf("\n");
			count2 = 0;
			print(array, count1+1, count2, n, m, total+1);
		}
		else
			print(array, count1, count2+1, n, m, total+1);
		}
	}

int main(int argv, char *argc[])
	{
	int n = atoi(argc[1]);
	int m = atoi(argc[2]);
	double **array;
	array = (double**) malloc(sizeof(double *) * n);
	int i,j;
	memory(array,0,n,m);
	int count = 3;
	for(i=0;i<n;i++)
	{
		for (j=0;j<m;j++)
			{			
			array[i][j] = atof(argc[count]);
			count = count + 1;
			}
	}
	print(array, 0, 0, n, m, 0);
	return 1;
	free(array);
	}
	
