#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char *argv[])
    {
	char *str[25];
       	int count = 1;
	int i;
	char *order[25];
	for(i=0;i<argc-1;i++)    
	{
	str[i] = argv[count];	
	count++;
	}
	
	int num = argc-1;
	int j=0; 
	int pos;
	while (j<num)
	{
		int min = 500;
		for(i=0;i<argc-1;i++)    
		{
			if(strlen(str[i]) <= min)
				{
				min = strlen(str[i]);
				pos = i;
				}
		}
		order[j] = str[pos];
		for (i=pos;i<argc-2;i++)
			str[i] = str[i+1];
		argc = argc-1;
		j = j+1;
	}
	for(i=0;i<num;i++)    
		printf("%s ", order[i]);
	printf("\n");
	return 1;
    }
