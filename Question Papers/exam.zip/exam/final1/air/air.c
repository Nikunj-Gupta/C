/*
 * Source file implementation of link list graph for finding route 
 * from nearest starting airport to nearest destination airport. 
 *
 * Complete the code in segments marked "ADD CODE HERE".
 *
 */

#include <air.h>

/********Private interface signature***********************/

/* Helper function: Create a data structure of airport */
static node *newNode();

/* Helper function: To find the distance from location A (x,y) to 
 * location B (x1,y1) 
 */
static double distance(double x, double y, double x1, double y1);

/* 
 * Helper function: To find the nearest airport with respect to the 
 * user specified location. 
 */
static void nearAirport(node *, double xInitial, double yInitial, double *xAirport, double *yAirport, char **name);

/* Helping function: To trace the airport names starting from 
 * nearest airport from starting position to nearest airport 
 * to destination position */
static char* map (node *, node*);

/* Helper function: To find the number of airports mentioned in the test file. */
static int nAirports(char *);

/* Helper function: To insert airport as specified from the test file. */
static node *insertAirport(char *, int , int , node *);

/* Helper function: To create airport nodes. */
static node *newAirport(char *, double , double , node *,node*);

/******************Public interfaces***************************/

node *createAirport(char *fileName)
    {
    node *stops=NULL;
    char **s;
    FILE *in;
    int xLocation, yLocation,len,i=0;

    /* 
     * Finding the number of airports from the test files.
     *
     */
    len = nAirports(fileName);

    /* Allocating memory for airport names */
    s = (char**)malloc(sizeof(char*)*len);
    for(i=0;i<len;i++)
        s[i] = (char*)malloc(sizeof(char)*512);

    i=0;

    /* 
     * Opening the file again to read and initialize airport name, x and y 
     * locations of the airport to the graph 
     */
    in = /* ADD CODE HERE */ 
    while(/* ADD CODE HERE */) // conditional check to reach end of file.
        {
        /* ADD CODE HERE */ // To read airport name, x and y locations from test file
        stops = insertAirport(s[i-1],xLocation, yLocation, stops);
        }
    /*ADD CODE HERE */ // To close the test file
    return stops;
    }

char* route(node *t, double xInitial, double yInitial, double xEnd, double yEnd)
    {
    double x, y;
    char *nameInitial="", *nameEnd="";
    node *p,*start, *end;

    // Finding nearest airport name with respect to starting X and Y positions.
    nearAirport(t,xInitial,yInitial,&x,&y,&nameInitial);

    // Finding nearest airport name with respect to destination X and Y positions.
    nearAirport(t,xEnd,yEnd,&x,&y,&nameEnd);

    // Searching for starting and destination airport nodes in the graph.
    while(t!=NULL)
        {
        p = t;
        while(p!=NULL)
            {
            if(/*ADD CODE HERE */) start = p; // To check whether starting airport name matches with that of airport names in the graph.
            if(/*ADD CODE HERE */) end = p; // To check whether destination airport name matches with that of airport names in the graph.
            p = p->down;
            }
        /* ADD CODE HERE */ // Continue searching the connected airports in X positions.
        }

    // Trace the path from starting airport to destination airport 
    return map(start,end);
    }

char* display(node *t)
    {
    /* 
     * The output should have the airport names with a space
     * between them.
     */
    char temp[512] = "";
    char *output = (char*) malloc(sizeof(char)*1024);
    node *p;
    while(t != NULL)
        {
        p = t;
        while(p!=NULL)
            {
            /*ADD CODE HERE */ // Add code to copy the airport names in the
            // format specified above to output buffer.
            }
        /*ADD CODE HERE */ // To continue to next airport having same location
        }
    return output;
    }


void deleteAirport(node *t)
    {
    /* ADD CODE HERE */
    // To completely delete the airport graph.
    // NOTE that you have to delete the allocated 
    // airport name and all possible airport nodes.
    }



/******************Private interfaces***************************/

static node *newNode()
    {
    node *n;
    n = (node*)malloc(sizeof(node));
    n->next = NULL;
    n->prev = NULL;
    n->down = NULL;
    n->up = NULL;
    return n;
    }

static double 
distance(double x, double y, double x1, double y1)
    {
    /*ADD CODE HERE */ // To find the distance between (x,y) and (x1,y1) points.
    }   

static void 
nearAirport(node *t, double xInitial, double yInitial, double *xAirport, double *yAirport, char **name)
    {
    /* ADD CODE HERE */
    // To find the nearest airport name, x and y locations
    // in the graph with respect to users x and y locations.
    }


static char* 
map (node* start, node* dest)
    {
    node *temp;
    char str[512];
    /* 
     * The output should have the airport names with a '->' (arrow)
     * between them.
     *
     */
    char *output = (char*)malloc(sizeof(char)*1024);

    while(start!=NULL)
        {
        /*ADD CODE HERE */ // Add code to copy the airport names in the
        // format specified above to output buffer.

        /*ADD CODE HERE */
        // Add logic to trace the route from
        // one starting airport to destination airport
        // NOTE that you can make use of all the
        // links: up, down, prev and next.
        }
    return output;
    }


static int 
nAirports(char *fileName)
    {
    /*ADD CODE HERE*/
    /* 
     * To find the number of airports provided by the test file.
     * The test file is parsed as command line argument.
     *
     */
    }


// Inserting the airport in the graph.
// The graph has a property that lower x value retains
// the primary node position. 
//  
node *insertAirport(char *aname, int x, int y, node *airport)
    {
    node *temp;
    if(airport==NULL) return newAirport(aname, x, y, 0,0);
    else if(airport->x == x && airport->y == y) return airport;
    else if(airport->x == x)
        {
        if(y > airport->y) 
            {
            temp = insertAirport(aname,x,y,airport->down);
            airport->down = temp;
            temp->up = airport;
            return airport;
            }
        else 
            {
            temp = newAirport(aname,x,y,0,airport);
            airport->up = temp;
            return temp;
            }
        }
    else if (x > airport->x)
        {
        temp = insertAirport(aname,x,y,airport->next);
        airport->next = temp;
        temp->prev = airport;
        return airport;
        }
    else 
        {
        temp =  newAirport(aname,x,y,airport,0);
        airport->prev = temp;
        return temp;
        }
    }

/*
 * Initializing new node with airport properties such as
 * x, y positions, airport names and links in the graph.
 */
node *newAirport(char *name, double xposition, double yposition, node *next,node* down)
    {
    node *p = newNode();
    p->name = name;
    p->x = xposition;
    p->y = yposition;
    p->next = next;
    p->prev = NULL;
    p->down = down;
    p->up = NULL;
    }
