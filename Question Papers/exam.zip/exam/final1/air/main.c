/*
 * main.c file
 * Test file for implementation of a linklist search on a graph
 *
 */
#include <air.h>

/************Private interface************************/
static void Fatal(int, char *);

/* Function to throw an error messgae depending on expected output */
void Fatal(int conditionValue, char *error)
    {
    if(!conditionValue) printf("%s\n", error);
    }

/* 
 * main function includes various test cases 
 * If any error condition is displayed, this means the
 * function implementation is incorrect.
 *
 */

int main(int argc, char *argv[])
	{
    node *airports;
    airports = createAirport(argv[1]);

    Fatal(!strcmp(display(airports),"bangalore mangalore hubli\
 frankfurt glasscow belgium newyork albquerque boston "),"display is incorrect.");

    Fatal(!strcmp(route(airports,110,200,100,1000),"bangalore->mangalore->hubli->"),"route is incorrect.");

    Fatal(!strcmp(route(airports,500,600,100,415),"albquerque->newyork->frankfurt->bangalore->mangalore->"),"route is incorrect.");

    deleteAirport(airports);
	return 0;
	}
