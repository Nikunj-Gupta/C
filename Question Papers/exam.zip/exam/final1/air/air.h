/*  
 *  air.h: Header file for implementation of linked list on a graph
 *  implemented to find path via airports 
 */

/*  
 *  Introduction: A link list is used here to find a path from the nearest
 *  starting airport to destination airport. The linked list is connected
 *  with parent data structures. The parent structures will have many
 *  child data structures. However the child from different parent structures
 *  are not connected. For example the one such linklist graph is shown below:
 *  
 *  bangalore------frankfurt--------newyork
 *      |              |               |
 *      |              |               |
 *      |              |               |
 *  mangalore       glasscow        albquerque
 *      |              |               |
 *      |              |               |
 *      |              |               |
 *    hubli         belgium         boston
 *
 *  
 * The connectivity is in both directions. For example bangalore  
 * is connected to frankfurt in next and previous links. Similarly
 * bangalore and hubli are connected via up and down links.
 * 
 * The airport names are placed with reference to X and Y locations.
 * The input to the data structure is supplied from test files.
 * One such test file is named as "test.dat". Your program will be
 * tested with different test files.
 *
 *
 * The format of the test files is shown below:
 *
 *
 * <airport1-name><space><x-location><space><y-location>
 * <airport2-name><space><x-location><space><y-location>
 *
 * Check "test.dat" file to understand the format.
 * 
 * Complete the function implementations in air.c file
 * and compile your program using makefile as shown below.
 * 
 * 'make all'
 *
 * Test your program using a default test.dat file as shown below.
 *
 * ./air test.dat
 *
 */


/*
 * Include all system header files.
 */
#include<stdio.h>
#include<stdlib.h>
#include<stdarg.h>
#include<time.h>
#include<math.h>
#include<string.h>

/*
 * Data structure to form a link list graph of airports.
 * name element is for airport name.
 * x and y elements are for airport locations in terms of x and y coordinates.
 * next, prev, down and up for connecting different airports.
 */

typedef struct nodeObject
    {
    double x;
    double y;
    char * name;
    struct nodeObject *next;
    struct nodeObject *prev;
    struct nodeObject *down;
    struct nodeObject *up;
    } node;

/**************Public interface signatures*********************/

/* Creating a graph using test file name. The test file provides the 
 * airport names with x and y locations */
node *createAirport(char *);

/* For displaying all the airports in the graph */
char* display(node *);

/* Implement to find route from the location specified by the user (in this
 * case as given in the main.c file). initialX and initialY provides
 * the user mentioned starting X and Y positions and destX, destY 
 * suggests the destination location mentioned by the user. 
 */
char* route(node *, double initialX, double initialY , double destX, double destY);


/* Deallocating memory for the graph */ 
void deleteAirport(node *);


