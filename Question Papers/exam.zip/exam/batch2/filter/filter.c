//Took 20 minutes to program

#include<stdio.h>
#include<stdlib.h>
void swap(int*, int*);

void swap(int *low, int *high)
    {
    int temp;
    temp = *low;
    *low = *high;
    *high = temp;
    }

int main(int argc, char *argv[])
    {
    FILE *in;

    char str[20]="";
    int samples,i=0, val, count=0, cutoffL, cutoffH;
    cutoffL = atoi(argv[1]);
    cutoffH = atoi(argv[2]);
    if(cutoffL > cutoffH) swap(&cutoffL, &cutoffH);
    in = fopen(argv[3],"r");
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    fscanf(in,"%d",&samples);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    fscanf(in,"%s",str);
    while(i<samples)
        {
        fscanf(in,"%d",&val);
        i++;
        if(abs(val) < cutoffL || abs(val) > cutoffH) count++;
        }
    fclose(in);
    i = 0;

    in = fopen(argv[3],"r");
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%d",&samples);
    printf("%d\n",count);
    fscanf(in,"%s",str);
    printf("%s ",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    fscanf(in,"%s",str);
    printf("%s\n",str);
    while(i<samples)
        {
        fscanf(in,"%d",&val);
        i++;
        if(abs(val) < cutoffL || abs(val) > cutoffH) printf("%d\n",val); 
        }
    fclose(in);
    }
