//Took 27 mins to program
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

float distance(float, float, float, float);

float distance(float sx, float sy, float dx, float dy)
    {
    return pow(pow(sx-dx,2) + pow(sy-dy,2),0.5);
    }

int main(int argc, char *argv[])
    {
    FILE *in;
    char station[20]="";
    int scount=0, dcount=0, i=1;
    float x,y,dist,sdist,ddist,startX, startY,destX,destY,smindist = 65535,dmindist=65535, travelled=0;
    startX = atof(argv[2]);
    startY = atof(argv[3]);
    destX = atof(argv[4]);
    destY = atof(argv[5]);
    in  = fopen(argv[1],"r");
    while(!feof(in))
        {
        fscanf(in,"%s",station);
        if(feof(in)) break;
        fscanf(in,"%f",&x);
        fscanf(in,"%f",&y);
        dist = distance(startX,startY,x,y);
        if(dist <= smindist) 
            {
            smindist = dist;
            scount=i;
            }
        dist = distance(destX, destY,x,y);
        if(dist <= dmindist) 
            {
            dmindist = dist;
            dcount=i;
            }
        i++;
        }
    fclose(in);
    i=1;
    in = fopen(argv[1],"r");
    while(!feof(in))
        {
        fscanf(in,"%s",station);
        if(feof(in)) break;
        fscanf(in,"%f",&x);
        fscanf(in,"%f",&y);
        if(i==dcount) 
            {
            printf("%s\n",station);
            travelled += distance(startX,startY,x,y);
            travelled += distance(x,y,destX,destY);
            break;
            }
        if(i>=scount) 
            {
            printf("%s->",station);
            travelled += distance(startX,startY,x,y);
            startX = x;
            startY = y;
            }
        i++;
        }
    printf("Distance travelled: %3.2f\n",travelled);
    return 1;
    }
