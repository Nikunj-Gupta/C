//Took 25 minutes to program

#include<stdio.h>

int main(int argc, char *argv[])
    {
    FILE *in;
    float time,first=65535,last=0;
    int fcount=0, lcount=0, i=1;
    char name[30]="", type[10]="";

    in = fopen(argv[1],"r");
    while(!feof(in))
        {
        fscanf(in,"%s",name);
        if(feof(in)) break;
        fscanf(in,"%f",&time);
        fscanf(in,"%s",type);
        if(time <= first)
            {
            first = time;
            fcount=i;
            }
        if(time >= last)
            {
            last = time;
            lcount=i;
            }
        i++;
        }
    fclose(in);
    i=0;
    in = fopen(argv[1],"r");
    while(i<fcount)
        {
        fscanf(in,"%s",name);
        //if(feof(in)) break;
        fscanf(in,"%f",&time);
        fscanf(in,"%s",type);
        i++;
        }
    printf("First candidate: %s %s\n",name, type);
    fclose(in);
    i=0;
    in = fopen(argv[1],"r");
    while(i<lcount)
        {
        fscanf(in,"%s",name);
        //if(feof(in)) break;
        fscanf(in,"%f",&time);
        fscanf(in,"%s",type);
        i++;
        }
    printf("Last candidate: %s %s\n",name, type);
    fclose(in);
    }   
