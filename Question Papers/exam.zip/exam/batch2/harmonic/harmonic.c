//Took 5 minutes to program

#include<stdio.h>
#include<stdlib.h>

int main(int argc, char *argv[])
    {
    int i=0;
    float acc=0;
    for (i=1;i<argc;i++)
        {
        acc += 1/atof(argv[i]);
        }
    printf("Harmonic mean: %3.2f\n",(float)(argc-1)/acc);
    return 1;
    }
