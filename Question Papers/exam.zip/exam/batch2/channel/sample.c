#include<stdio.h>

int main()
    {
    int x = 0b1100110111;
    printf("%d\n",x);
    return 1;
    }
