//Took 28 minutes .. same  as vending problem of batch1

#include<stdio.h>

int main(int argc, char *argv[])
    {
    short int channels, sony, star, zee, ndtv, aajtak, cnnibn;
    int price=0, amount=0;
    scanf("%d",(int*)&channels);
    sony = (channels & 0b1100000001) >> 8;
    star = (channels & 0b0011100000) >> 5 ;
    zee = (channels &  0b0000011000) >> 3 ;
    ndtv = (channels & 0b0000000100) >> 2;
    aajtak = (channels & 0b0000000010) >> 1;
    cnnibn = (channels & 0b0000000001);
    price = atoi(argv[1]);
    printf("Channels selected:\n");
    amount += (price & 0b11111100000000000000000000000000)>>26;

    switch (sony)
        {
        case 0:
            printf("SonyTV\n");
            break;
        case 1:
            printf("SonyPix\n");
            break;
        case 2:
            printf("SetMax\n");
            break;
        case 3:
            printf("SonyMix\n");
            break;
        }
    switch (star)
        {
        case 0:
            printf("StarPlus\n");
            amount += (price & 0b00000011111100000000000000000000)>>20;
            break;
        case 1:
            printf("StarWorld\n");
            amount += (price & 0b00000011111100000000000000000000)>>20;
            break;
        case 2:
            printf("StarGold\n");
            amount += (price & 0b00000011111100000000000000000000)>>20;
            break;
        case 3:
            printf("StarMovies\n");
            amount += (price & 0b00000011111100000000000000000000)>>20;
            break;
        case 4:
            printf("StarUtsav\n");
            amount += (price & 0b00000011111100000000000000000000)>>20;
            break;
        default:
            break;
        }
    amount += (price & 0b00000000000011111000000000000000)>>15;
    switch (zee)
        {
        case 0:
            printf("ZeeTV\n");
            break;
        case 1:
            printf("ZeeClassic\n");
            break;
        case 2:
            printf("ZeeCafe\n");
            break;
        case 3:
            printf("ZeeCinema\n");
            break;
        }

    amount += (price & 0b00000000000000000111110000000000)>>10;
    switch (ndtv)
        {
        case 0:
            printf("NDTV24X7\n");
            break;
        default:
            printf("NDTVProfit\n");
            break;
        }
    if(aajtak)
        {
        amount += (price & 0b00000000000000000000001111111000)>>3;
        printf("AAJTAK\n");
        }
    if(cnnibn)
        {
        amount += (price & 0b00000000000000000000000000000111);
        printf("CNNIBN\n");
        }


    printf("\nTotal price:\n");
    printf("%d\n",amount);
    return 1;
    }
