/*
NAME=SIMRAN DOKANIA
ROLL-NO.=IMT2013044
EMAIL-ID=Simran.Dokania@iiitb.org
DATE=1/10/2013
*/
#include<stdio.h>
#include<stdlib.h>
int main(int argc, char *argv[])
    {
    long int number=atoi(argv[1]);
    long int price=0;
    number=number&111111111;
    price+=number;
    number=number>>9;
    number=number&111111;
    price+=number;
    number=number>>6;
    number=number&111111;
    price+=number;
    number=number>>6;
    number=number&1111;
    price+=number;
    printf("PRICE:%ld\n,price");
    }
