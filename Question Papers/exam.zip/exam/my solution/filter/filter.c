/*
NAME=SIMRAN DOKANIA
ROLL-NO.=IMT2013044
EMAIL-ID=Simran.Dokania@iiitb.org
DATE=1/10/2013
*/
#include<stdio.h>
#include<stdlib.h>
int main(int argv, char *argc[])
    {
    int number,count=0;
    int sample_value;
    int threshold_val=atoi(argc[1]);
    char details1[25];
    char details2[25];
    FILE *input;
    input=fopen(argc[2],"r");
    fscanf(input,"%s",details1);
    fscanf(input,"%s %d",details1, &sample_value);
    fscanf(input,"%s %s",details1, details2);
    fscanf(input,"%s",details1);
    while(!feof(input))
        {
        fscanf(input,"%d",&number);
        if(number<=threshold_val && number>=(-1)*threshold_val)
            count++;
	    }
    fclose(input);
    input=fopen(argc[2],"r");
    fscanf(input,"%s",details1);
    printf("%s\n",details1);
    fscanf(input,"%s %d",details1,&sample_value);
    printf("%s %d\n",details1, count);
    fscanf(input,"%s %s",details1, details2);
    printf("%s %s\n",details1, details2);
    fscanf(input,"%s",details1);
    printf("%s\n",details1);
    while(!feof(input))
        {
        fscanf(input,"%d",&number);
        if(number<=threshold_val && number>=(-1)*threshold_val)
        	 printf("%d\n",number);   
    	}
    fclose(input);
    }



