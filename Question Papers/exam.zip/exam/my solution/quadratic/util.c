extern double real_part;
void compute(double a,double b,double c,double *root1,double *root2,double*complex_part)
    {
    *root1=((-1*b)+sqrt(b*b-4*a*c))/2*a;
    *root2=((-1*b)-sqrt(b*b-4*a*c))/2*a;
    if(b*b-4*a*c<0)
        {
        real_part=(-1*b)/2*a;
        *complex_part=(b*b-4*a*c)/2*a;
        }
    }
