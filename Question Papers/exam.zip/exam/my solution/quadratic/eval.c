/*
NAME=SIMRAN DOKANIA
ROLL-NO.=IMT2013044
EMAIL-ID=Simran.Dokania@iiitb.org
DATE=1/10/2013
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
double real_part;
void compute(double,double,double,double*,double*,double*);
int main(int argv, char *argc[])
    {
    double x=atoi(argc[1]);
    double y=atoi(argc[2]);
    double z=atoi(argc[3]);
    double root1=0;
    double root2=0;
    double complex_part=0;
    compute(x,y,z,&root1,&root2,&complex_part);
    if(y*y-4*x*z>=0)
        {
        printf("root1: %0.2lf\n",root1);
        printf("root2: %0.2lf\n",root2);
        }
    else
        {
        printf("root1: %0.2lf + %0.2lfi\n",real_part,fabs(complex_part));
        printf("root2: %0.2lf - %0.2lfi\n",real_part,fabs(complex_part));
        }
    }
