/*
NAME=SIMRAN DOKANIA
ROLL-NO.=IMT2013044
EMAIL-ID=Simran.Dokania@iiitb.org
DATE=1/10/2013
*/
#include<stdio.h>
#include<stdlib.h>
int main(int argv, char *argc[])
    {
    FILE *input;
    input=fopen(argc[1],"r");
    char detail1[10];
    double detail2;
    double detail3;
    int detail4;
    double gallons=0;
    double total_gallons=0;
    while(!feof(input))
        {
        fscanf(input,"%s",detail1);
        fscanf(input,"%lf",&detail2);
        fscanf(input,"%lf",&detail3);
        fscanf(input,"%d",&detail4);
        gallons=detail3/detail2;
        if(detail4>1)
            gallons=gallons/detail4;
        total_gallons+=gallons;
        }
    printf("The total gallons consumed is %0.2lf\n",total_gallons);
    fclose(input);
    }


