/*
NAME=SIMRAN DOKANIA
ROLL-NO.=IMT2013044
EMAIL-ID=Simran.Dokania@iiitb.org
DATE=1/10/2013
*/
#include<stdio.h>
#include<stdlib.h>
int main(int argv, char *argc[])
    {
    int i,j;
    int num=0;
    int count=0;
    FILE *input1,*input2,*input3;
    input1=fopen("prime.dat","w");
    input2=fopen("even.dat","w");
    input3=fopen("odd.dat","w");
    for(i=1;i<argv;i++)
        {
        num=atoi(argc[i]);
        count=0;
        if(num==1)
            count++;
        for(j=1;j<=num;j++)
            {
            if(num%j==0)
                count++;
            }
        if(count==2)
            fprintf(input1,"%d ",num);
        else if(num%2==0)
            fprintf(input2,"%d ",num);
        else if(num%2!=0)
            fprintf(input3,"%d ",num);
        }
    fclose(input1);
    fclose(input2);
    fclose(input3);
    }



